#!/usr/bin/env node

import { randomUUID } from 'node:crypto'
import { readFile, realpath, stat } from 'node:fs/promises'
import net from 'node:net'
import path from 'node:path'
import process from 'node:process'
import { spawn } from 'node:child_process'
import {
  CLI_VERSION,
  MAX_REQUEST_BYTES,
  PROTOCOL_VERSION,
  getDataDirectory,
  getRuntimeEndpoint,
  readBridgeToken,
} from './lib/config.mjs'

const IMAGE_TYPES = {
  '.gif': 'image/gif',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
}
const MAX_IMAGE_BYTES = 10 * 1024 * 1024
const LOCAL_IMAGE_PATTERN = /!\[[^\]]*]\((?:<([^>]+)>|([^\s)]+))(?:\s+["'][^"']*["'])?\)/g

main().catch((error) => {
  const normalized = normalizeError(error)
  if (process.argv.includes('--json')) {
    process.stdout.write(`${JSON.stringify({ ok: false, error: normalized })}\n`)
  } else {
    process.stderr.write(`[${normalized.code}] ${normalized.message}\n`)
  }
  process.exitCode = normalized.exitCode
})

async function main() {
  const args = process.argv.slice(2)
  if (args.includes('--version') || args[0] === 'version') {
    process.stdout.write(`${CLI_VERSION}\n`)
    return
  }
  if (!args.length || args.includes('--help') || args[0] === 'help') {
    printHelp()
    return
  }
  const json = takeFlag(args, '--json')
  const [group, action] = args
  if (group === 'doctor') {
    return output(await request('doctor'), json, formatDoctor)
  }
  if (group === 'platforms' && action === 'list') {
    return output(await request('platforms.list'), json, formatPlatforms)
  }
  if (group === 'auth' && action === 'check') {
    args.splice(0, 2)
    const platform = takeOption(args, '--platform')
    assertNoArguments(args)
    return output(
      await request('auth.check', platform ? { platform } : {}),
      json,
      formatAuth,
    )
  }
  if (group === 'draft' && action === 'prepare') {
    args.splice(0, 2)
    return prepareDraft(args, json)
  }
  if (group === 'draft' && action === 'create') {
    args.splice(0, 2)
    return createDraft(args, json)
  }
  if (group === 'task' && ['get', 'watch', 'cancel'].includes(action)) {
    args.splice(0, 2)
    return handleTask(action, args, json)
  }
  if (group === 'uninstall') return uninstall()
  throw cliError('UNKNOWN_COMMAND', '未知命令，运行 geo-action --help 查看用法', 2)
}

async function prepareDraft(args, json) {
  const file = takePositional(args, '请提供 Markdown 文件路径')
  const platformValue = takeOption(args, '--platform')
  const assetPaths = takeRepeatedOption(args, '--asset')
  const coverValue = takeOption(args, '--cover')
  const title = takeOption(args, '--title')
  const summary = takeOption(args, '--summary')
  const tags = takeRepeatedOption(args, '--tag')
  const juejinCategoryName = takeOption(args, '--juejin-category')
  assertNoArguments(args)

  const markdownPath = await assertReadableFile(file)
  const markdownBuffer = await readFile(markdownPath)
  if (markdownBuffer.byteLength > 8 * 1024 * 1024) {
    throw cliError('MARKDOWN_TOO_LARGE', 'Markdown 不得超过 8MB', 2)
  }
  const markdown = markdownBuffer.toString('utf8')
  const platforms = platformValue
    ? parsePlatformList(platformValue)
    : (await request('platforms.list')).map((item) => item.id)
  const localAssets = await collectLocalAssets(markdownPath, markdown, assetPaths)
  const cover = coverValue ? await resolveCover(coverValue) : undefined
  const input = {
    markdown,
    platforms,
    localAssets,
    title,
    summary,
    tags: tags.length ? tags : undefined,
    cover,
    juejinCategoryName,
  }
  assertPayloadSize(input)
  const result = await request('draft.prepare', input)
  output(result, json, formatPreparedDraft)
}

async function createDraft(args, json) {
  const preparedId = takePositional(args, '请提供 prepared-id')
  const confirm = takeFlag(args, '--confirm')
  const allowDuplicateCreation = takeFlag(args, '--allow-duplicate')
  const clientRequestId = takeOption(args, '--request-id') || randomUUID()
  assertNoArguments(args)
  if (!confirm) {
    throw cliError(
      'CONFIRMATION_REQUIRED',
      '创建草稿需要 --confirm；请先向用户展示 prepare 结果并取得确认',
      2,
    )
  }
  const result = await request('draft.create', {
    preparedId,
    clientRequestId,
    confirm,
    allowDuplicateCreation,
  })
  output(result, json, formatTask)
}

async function handleTask(action, args, json) {
  const taskId = takePositional(args, '请提供 task-id')
  assertNoArguments(args)
  if (action === 'watch') {
    while (true) {
      const task = await request('task.get', { taskId })
      if (!json) renderTaskProgress(task)
      if (task.status !== 'publishing') {
        if (json) output(task, true, formatTask)
        return
      }
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }
  }
  const result = await request(
    action === 'cancel' ? 'task.cancel' : 'task.get',
    { taskId },
  )
  output(result, json, formatTask)
}

async function request(command, input = {}) {
  const token = await readBridgeToken().catch(() => {
    throw cliError('HOST_NOT_INSTALLED', 'CLI 尚未完成安装或配对', 3)
  })
  const id = randomUUID()
  const payload = `${JSON.stringify({ id, token, command, input })}\n`
  if (Buffer.byteLength(payload) > MAX_REQUEST_BYTES + 1024 * 1024) {
    throw cliError('REQUEST_TOO_LARGE', '请求超过 24MB', 2)
  }
  const response = await sendToHost(payload, id)
  if (response.protocolVersion !== PROTOCOL_VERSION) {
    throw cliError(
      'PROTOCOL_MISMATCH',
      `CLI 协议 ${PROTOCOL_VERSION} 与扩展协议 ${response.protocolVersion ?? '未知'} 不兼容`,
      4,
    )
  }
  if (!response.ok) {
    throw cliError(
      response.error?.code || 'AGENT_ERROR',
      response.error?.message || '扩展拒绝了请求',
      5,
      response.error?.details,
    )
  }
  return response.data
}

function sendToHost(payload, requestId) {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection(getRuntimeEndpoint())
    let buffer = ''
    const timer = setTimeout(() => {
      socket.destroy()
      reject(cliError('BRIDGE_TIMEOUT', '本机 Bridge 在 125 秒内没有响应', 4))
    }, 125_000)
    socket.setEncoding('utf8')
    socket.on('connect', () => socket.write(payload))
    socket.on('data', (chunk) => {
      buffer += chunk
      const newline = buffer.indexOf('\n')
      if (newline < 0) return
      clearTimeout(timer)
      socket.end()
      try {
        const value = JSON.parse(buffer.slice(0, newline))
        if (value.id !== requestId) {
          reject(cliError('RESPONSE_MISMATCH', 'Bridge 返回了错误的请求 ID', 4))
          return
        }
        resolve(value)
      } catch {
        reject(cliError('INVALID_RESPONSE', 'Bridge 返回了无效 JSON', 4))
      }
    })
    socket.on('error', (error) => {
      clearTimeout(timer)
      const code = error && typeof error === 'object' ? error.code : undefined
      reject(cliError(
        'BRIDGE_UNAVAILABLE',
        code === 'ENOENT' || code === 'ECONNREFUSED'
          ? '请打开 Chrome，确认 GEO Action 0.3.0 已启用且 Native Host 已安装'
          : '无法连接 GEO Action Native Host',
        3,
      ))
    })
  })
}

async function collectLocalAssets(markdownPath, markdown, explicitPaths) {
  const markdownDirectory = path.dirname(markdownPath)
  const candidates = new Map()
  for (const match of markdown.matchAll(LOCAL_IMAGE_PATTERN)) {
    const source = (match[1] || match[2] || '').trim()
    if (!source || /^(?:https?:|data:)/i.test(source)) continue
    const filePath = path.resolve(markdownDirectory, decodeURIComponent(source))
    candidates.set(source, filePath)
  }
  for (const assetPath of explicitPaths) {
    const filePath = await assertReadableFile(assetPath)
    candidates.set(path.basename(filePath), filePath)
  }

  const assets = {}
  let totalBytes = 0
  for (const [source, candidate] of candidates) {
    let filePath
    try {
      filePath = await assertReadableFile(candidate)
    } catch {
      continue
    }
    const extension = path.extname(filePath).toLowerCase()
    const mime = IMAGE_TYPES[extension]
    if (!mime) {
      throw cliError('UNSUPPORTED_IMAGE', `不支持的图片格式：${filePath}`, 2)
    }
    const content = await readFile(filePath)
    if (content.byteLength > MAX_IMAGE_BYTES) {
      throw cliError('IMAGE_TOO_LARGE', `图片超过 10MB：${filePath}`, 2)
    }
    totalBytes += content.byteLength
    if (totalBytes > MAX_REQUEST_BYTES) {
      throw cliError('REQUEST_TOO_LARGE', 'Markdown 与图片总量超过 24MB', 2)
    }
    const dataUrl = `data:${mime};base64,${content.toString('base64')}`
    assets[source.replace(/^\.\//, '').replaceAll('\\', '/')] = dataUrl
    assets[path.basename(filePath)] = dataUrl
  }
  return assets
}

async function resolveCover(value) {
  if (/^(?:https?:|data:image\/)/i.test(value)) return value
  const filePath = await assertReadableFile(value)
  const extension = path.extname(filePath).toLowerCase()
  const mime = IMAGE_TYPES[extension]
  if (!mime) throw cliError('UNSUPPORTED_IMAGE', `不支持的封面格式：${filePath}`, 2)
  const content = await readFile(filePath)
  if (content.byteLength > MAX_IMAGE_BYTES) {
    throw cliError('IMAGE_TOO_LARGE', '封面超过 10MB', 2)
  }
  return `data:${mime};base64,${content.toString('base64')}`
}

async function assertReadableFile(value) {
  const resolved = await realpath(path.resolve(value)).catch(() => {
    throw cliError('FILE_NOT_FOUND', `文件不存在：${value}`, 2)
  })
  const info = await stat(resolved)
  if (!info.isFile()) throw cliError('NOT_A_FILE', `不是普通文件：${value}`, 2)
  return resolved
}

function assertPayloadSize(input) {
  if (Buffer.byteLength(JSON.stringify(input)) > MAX_REQUEST_BYTES) {
    throw cliError('REQUEST_TOO_LARGE', 'Markdown 与图片总请求超过 24MB', 2)
  }
}

function output(data, json, formatter) {
  if (json) {
    process.stdout.write(`${JSON.stringify({ ok: true, data })}\n`)
    return
  }
  process.stdout.write(`${formatter(data)}\n`)
}

function formatDoctor(data) {
  return [
    'GEO Action CLI 连接正常',
    `CLI: ${CLI_VERSION}`,
    `扩展: ${data.extensionVersion}`,
    `扩展 ID: ${data.extensionId}`,
    `协议: ${data.protocolVersion}`,
  ].join('\n')
}

function formatPlatforms(data) {
  return data.map((item) => `${item.id}\t${item.name}\t${item.format}`).join('\n')
}

function formatAuth(data) {
  return Object.entries(data.states).map(([platform, state]) => (
    `${platform}\t${state?.authenticated ? '已登录' : `未登录：${state?.error || '请检查登录状态'}`}`
  )).join('\n')
}

function formatPreparedDraft(data) {
  const lines = [
    `准备完成：${data.preparedId}`,
    `标题：${data.title}`,
    `平台：${data.platforms.join(', ')}`,
    `字数：${data.wordCount}`,
    `阻断：${data.blockedCount}；提醒：${data.warningCount}`,
    `有效期至：${new Date(data.expiresAt).toLocaleString()}`,
  ]
  for (const issue of data.issues) {
    lines.push(`- [${issue.severity}] ${issue.platform} / ${issue.title}：${issue.message}`)
  }
  return lines.join('\n')
}

function formatTask(data) {
  return [
    `任务：${data.id}`,
    `状态：${data.status}`,
    ...data.tasks.map((item) => (
      `- ${item.platform}: ${item.status}${item.message ? ` · ${item.message}` : ''}` +
      `${item.result?.articleUrl ? ` · ${item.result.articleUrl}` : ''}`
    )),
  ].join('\n')
}

function renderTaskProgress(data) {
  process.stdout.write(`${formatTask(data)}\n`)
}

function parsePlatformList(value) {
  const platforms = [...new Set(value.split(',').map((item) => item.trim()).filter(Boolean))]
  if (!platforms.length) throw cliError('PLATFORMS_REQUIRED', '平台列表不能为空', 2)
  return platforms
}

function takePositional(args, message) {
  const value = args[0]
  if (!value || value.startsWith('--')) {
    throw cliError('MISSING_ARGUMENT', `${message}，并将其放在选项之前`, 2)
  }
  args.shift()
  return value
}

function takeFlag(args, name) {
  const index = args.indexOf(name)
  if (index < 0) return false
  args.splice(index, 1)
  return true
}

function takeOption(args, name) {
  const index = args.indexOf(name)
  if (index < 0) return undefined
  const value = args[index + 1]
  if (!value || value.startsWith('--')) {
    throw cliError('MISSING_ARGUMENT', `${name} 缺少值`, 2)
  }
  args.splice(index, 2)
  return value
}

function takeRepeatedOption(args, name) {
  const values = []
  while (args.includes(name)) values.push(takeOption(args, name))
  return values
}

function assertNoArguments(args) {
  if (args.length) throw cliError('UNKNOWN_ARGUMENT', `未知参数：${args.join(' ')}`, 2)
}

function cliError(code, message, exitCode, details) {
  return Object.assign(new Error(message), { code, exitCode, details })
}

function normalizeError(error) {
  return {
    code: error?.code || 'CLI_ERROR',
    message: error instanceof Error ? error.message : 'CLI 执行失败',
    details: error?.details,
    exitCode: Number.isInteger(error?.exitCode) ? error.exitCode : 1,
  }
}

async function uninstall() {
  const dataDirectory = getDataDirectory()
  const script = process.platform === 'win32'
    ? path.join(dataDirectory, 'uninstall.ps1')
    : path.join(dataDirectory, 'uninstall.sh')
  const command = process.platform === 'win32' ? 'powershell.exe' : '/bin/sh'
  const commandArgs = process.platform === 'win32'
    ? ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script]
    : [script]
  const child = spawn(command, commandArgs, { detached: true, stdio: 'inherit' })
  child.unref()
}

function printHelp() {
  process.stdout.write(`GEO Action CLI ${CLI_VERSION}

用法：
  geo-action doctor [--json]
  geo-action platforms list [--json]
  geo-action auth check [--platform <id>] [--json]
  geo-action draft prepare <article.md> --platform wechat,zhihu [--asset image.png] [--json]
  geo-action draft create <prepared-id> --confirm [--allow-duplicate] [--json]
  geo-action task get <task-id> [--json]
  geo-action task watch <task-id> [--json]
  geo-action task cancel <task-id> [--json]
  geo-action uninstall
`)
}
