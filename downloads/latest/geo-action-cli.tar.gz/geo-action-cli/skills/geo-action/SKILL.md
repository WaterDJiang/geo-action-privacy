---
name: geo-action
description: Use GEO Action through its installed local CLI to prepare Markdown, validate platform content, check login state, create editable multi-platform drafts after explicit confirmation, and watch or cancel Agent-created tasks. Use when the user asks an AI tool to send a local Markdown article to GEO Action, create platform drafts, inspect GEO Action platform readiness, or follow a GEO Action CLI task.
---

# GEO Action

Use the installed `geo-action` CLI as the only control surface. Do not drive the Side Panel or platform pages directly.

## Invocation

- Codex users may explicitly invoke this workflow with `$geo-action <request>`.
- Claude Code users may explicitly invoke it with `/geo-action <request>`.
- Also use this workflow for a plain-language request that clearly asks to use GEO Action.
- The Native Host is started on demand by Chrome; do not ask the user to start a separate daemon.

## Workflow

1. Verify the bridge:

   ```bash
   geo-action doctor --json
   ```

   If the command is missing or reports `HOST_NOT_INSTALLED` / `BRIDGE_UNAVAILABLE`, stop. Tell the user to open GEO Action → 设置 → CLI 与本地 AI and follow the displayed installation or troubleshooting steps. Do not install software without approval.

2. Resolve platforms when needed:

   ```bash
   geo-action platforms list --json
   geo-action auth check --platform <platform-id> --json
   ```

   Use only IDs returned by `platforms list`. A failed login check blocks that platform; do not attempt to bypass verification, CAPTCHA, or risk controls.

3. Prepare the Markdown:

   ```bash
   geo-action draft prepare "/absolute/path/article.md" \
     --platform wechat,zhihu \
     --asset "/absolute/path/image.png" \
     --json
   ```

   Add `--asset` only for images the user explicitly selected. Use `--cover`, `--title`, `--summary`, and repeated `--tag` only when the user supplied or approved those overrides.

4. Review the returned preparation result.

   - If `blockedCount > 0`, stop and report each blocking issue with its suggestion.
   - If `missingAssets` is non-empty, stop and ask the user to provide the missing images or revise the Markdown.
   - Show `preparedId`, title, selected platforms, expiry, warnings, and content issues.
   - Preparation does not create any platform draft.

5. Obtain explicit confirmation after showing the preparation result.

   Do not infer confirmation from a general earlier request. Ask whether to create the listed platform drafts. Creating drafts is allowed only after the user confirms this exact prepared result.

6. Create drafts:

   ```bash
   geo-action draft create <prepared-id> \
     --confirm \
     --request-id <stable-request-id> \
     --json
   ```

   Reuse the same request ID when retrying an uncertain CLI response. Add `--allow-duplicate` only when the preparation or user explicitly calls for creating another copy despite duplicate protection.

7. Watch the task:

   ```bash
   geo-action task watch <task-id> --json
   ```

   Report each platform as `success`, `duplicate`, `needs_review`, `failed`, or `cancelled`. Describe `needs_review` as “草稿待确认” and preserve its next action. A successful result is an editable draft, never a public publication.

## Task controls

Query or cancel only the task ID returned by the current GEO Action flow:

```bash
geo-action task get <task-id> --json
geo-action task cancel <task-id> --json
```

Cancellation stops work that has not started. It does not delete or roll back drafts already created.

## Safety

- Never request or expose cookies, API keys, tokens, authorization headers, or Chrome storage.
- Never call internal extension messages, arbitrary URLs, or platform scripts.
- Never retry a platform write automatically.
- Never claim public publication; GEO Action creates drafts for human review.
- Preserve raw CLI error codes and messages when reporting failures.
