#!/usr/bin/env node

import { timingSafeEqual } from 'node:crypto'
import { chmod, mkdir, rm } from 'node:fs/promises'
import net from 'node:net'
import path from 'node:path'
import process from 'node:process'
import {
  MAX_CHUNKS,
  MAX_REQUEST_BYTES,
  RAW_CHUNK_BYTES,
  ensureBridgeToken,
  getRuntimeEndpoint,
  readInstallConfig,
} from './lib/config.mjs'

const MAX_NATIVE_INPUT_BYTES = 64 * 1024 * 1024
const MAX_CLIENT_BUFFER_BYTES = MAX_REQUEST_BYTES + 1024 * 1024
const REQUEST_TIMEOUT_MS = 120_000
const pendingRequests = new Map()

let nativeBuffer = Buffer.alloc(0)
let expectedNativeLength = null
let server

main().catch((error) => {
  process.stderr.write(`GEO Action Native Host 启动失败：${safeMessage(error)}\n`)
  process.exitCode = 1
})

async function main() {
  const config = await readInstallConfig()
  assertExtensionOrigin(config.extensionId)
  const token = await ensureBridgeToken()
  const endpoint = getRuntimeEndpoint()
  await prepareEndpoint(endpoint)
  server = net.createServer((socket) => acceptClient(socket, token))
  server.on('error', (error) => {
    process.stderr.write(`GEO Action Bridge 监听失败：${safeMessage(error)}\n`)
    shutdown(1)
  })
  server.listen(endpoint, async () => {
    if (process.platform !== 'win32') await chmod(endpoint, 0o600)
  })

  process.stdin.on('data', receiveNativeData)
  process.stdin.on('end', () => shutdown(0))
  process.stdin.on('error', () => shutdown(1))
  process.on('SIGTERM', () => shutdown(0))
  process.on('SIGINT', () => shutdown(0))
}

function assertExtensionOrigin(extensionId) {
  const origin = process.argv[2]
  if (origin && origin !== `chrome-extension://${extensionId}/`) {
    throw new Error('调用扩展 ID 与安装配置不一致')
  }
}

async function prepareEndpoint(endpoint) {
  if (process.platform === 'win32') return
  await mkdir(path.dirname(endpoint), { recursive: true, mode: 0o700 })
  await rm(endpoint, { force: true })
}

function acceptClient(socket, expectedToken) {
  let buffer = Buffer.alloc(0)
  socket.setEncoding('utf8')
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, Buffer.from(chunk)])
    if (buffer.byteLength > MAX_CLIENT_BUFFER_BYTES) {
      sendClientError(socket, undefined, 'REQUEST_TOO_LARGE', '请求超过 24MB')
      socket.destroy()
      return
    }
    let newlineIndex
    while ((newlineIndex = buffer.indexOf(0x0a)) >= 0) {
      const line = buffer.subarray(0, newlineIndex).toString('utf8')
      buffer = buffer.subarray(newlineIndex + 1)
      if (!line.trim()) continue
      receiveClientRequest(socket, expectedToken, line)
    }
  })
  socket.on('error', () => undefined)
  socket.on('close', () => {
    for (const [id, pending] of pendingRequests) {
      if (pending.socket !== socket) continue
      clearTimeout(pending.timer)
      pendingRequests.delete(id)
    }
  })
}

function receiveClientRequest(socket, expectedToken, line) {
  let value
  try {
    value = JSON.parse(line)
  } catch {
    sendClientError(socket, undefined, 'INVALID_JSON', 'CLI 请求不是有效 JSON')
    return
  }
  const id = typeof value?.id === 'string' ? value.id : undefined
  if (!id || id.length > 200 || pendingRequests.has(id)) {
    sendClientError(socket, id, 'INVALID_REQUEST_ID', 'CLI 请求 ID 无效或重复')
    return
  }
  if (!safeTokenEqual(value.token, expectedToken)) {
    sendClientError(socket, id, 'AUTH_FAILED', 'CLI 配对 token 无效，请重新安装')
    return
  }
  if (typeof value.command !== 'string' ||
    (value.input !== undefined && (!value.input || typeof value.input !== 'object'))) {
    sendClientError(socket, id, 'INVALID_REQUEST', 'CLI 请求格式无效')
    return
  }
  const request = { command: value.command, input: value.input }
  const requestBytes = Buffer.from(JSON.stringify(request), 'utf8')
  if (requestBytes.byteLength > MAX_REQUEST_BYTES) {
    sendClientError(socket, id, 'REQUEST_TOO_LARGE', '请求超过 24MB')
    return
  }
  const timer = setTimeout(() => {
    pendingRequests.delete(id)
    sendClientError(socket, id, 'EXTENSION_TIMEOUT', '扩展在 120 秒内没有接收请求')
  }, REQUEST_TIMEOUT_MS)
  pendingRequests.set(id, { socket, timer })
  if (requestBytes.byteLength <= RAW_CHUNK_BYTES) {
    writeNativeMessage({ type: 'agent.request', id, request })
    return
  }
  const total = Math.ceil(requestBytes.byteLength / RAW_CHUNK_BYTES)
  if (total > MAX_CHUNKS) {
    clearTimeout(timer)
    pendingRequests.delete(id)
    sendClientError(socket, id, 'TOO_MANY_CHUNKS', '请求分块数量超过限制')
    return
  }
  for (let index = 0; index < total; index += 1) {
    const chunk = requestBytes.subarray(
      index * RAW_CHUNK_BYTES,
      Math.min((index + 1) * RAW_CHUNK_BYTES, requestBytes.byteLength),
    )
    writeNativeMessage({
      type: 'agent.request.chunk',
      id,
      index,
      total,
      data: chunk.toString('base64'),
    })
  }
  writeNativeMessage({ type: 'agent.request.commit', id })
}

function receiveNativeData(chunk) {
  nativeBuffer = Buffer.concat([nativeBuffer, chunk])
  while (true) {
    if (expectedNativeLength === null) {
      if (nativeBuffer.byteLength < 4) return
      expectedNativeLength = nativeBuffer.readUInt32LE(0)
      nativeBuffer = nativeBuffer.subarray(4)
      if (expectedNativeLength < 1 || expectedNativeLength > MAX_NATIVE_INPUT_BYTES) {
        process.stderr.write('GEO Action Native Host 收到超限消息\n')
        shutdown(1)
        return
      }
    }
    if (nativeBuffer.byteLength < expectedNativeLength) return
    const messageBuffer = nativeBuffer.subarray(0, expectedNativeLength)
    nativeBuffer = nativeBuffer.subarray(expectedNativeLength)
    expectedNativeLength = null
    receiveExtensionMessage(messageBuffer)
  }
}

function receiveExtensionMessage(messageBuffer) {
  let message
  try {
    message = JSON.parse(messageBuffer.toString('utf8'))
  } catch {
    return
  }
  if (message?.type !== 'agent.response' || typeof message.id !== 'string') return
  const pending = pendingRequests.get(message.id)
  if (!pending) return
  clearTimeout(pending.timer)
  pendingRequests.delete(message.id)
  writeClient(pending.socket, {
    id: message.id,
    ...message.response,
  })
}

function writeNativeMessage(message) {
  const payload = Buffer.from(JSON.stringify(message), 'utf8')
  const header = Buffer.alloc(4)
  header.writeUInt32LE(payload.byteLength, 0)
  process.stdout.write(Buffer.concat([header, payload]))
}

function writeClient(socket, value) {
  if (!socket.destroyed) socket.write(`${JSON.stringify(value)}\n`)
}

function sendClientError(socket, id, code, message) {
  writeClient(socket, {
    id,
    protocolVersion: 1,
    ok: false,
    error: { code, message },
  })
}

function safeTokenEqual(value, expected) {
  if (typeof value !== 'string') return false
  const left = Buffer.from(value)
  const right = Buffer.from(expected)
  return left.byteLength === right.byteLength && timingSafeEqual(left, right)
}

function safeMessage(error) {
  return error instanceof Error ? error.message : '未知错误'
}

async function shutdown(exitCode) {
  for (const pending of pendingRequests.values()) clearTimeout(pending.timer)
  pendingRequests.clear()
  if (server) server.close()
  const endpoint = getRuntimeEndpoint()
  if (process.platform !== 'win32') await rm(endpoint, { force: true }).catch(() => undefined)
  process.exit(exitCode)
}
