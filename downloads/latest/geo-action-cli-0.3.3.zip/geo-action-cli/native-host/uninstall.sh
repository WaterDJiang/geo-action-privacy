#!/bin/sh
set -eu

task_user_home="$(node -p "require('node:os').homedir()")"
system_name="$(uname -s)"
if [ -n "${GEO_ACTION_TEST_ROOT:-}" ]; then
  install_directory="$GEO_ACTION_TEST_ROOT/data"
  manifest_path="$GEO_ACTION_TEST_ROOT/native-hosts/cn.wattter.geo_action.json"
  binary_path="$GEO_ACTION_TEST_ROOT/bin/geo-action"
  codex_skill_path="$GEO_ACTION_TEST_ROOT/codex-skills/geo-action"
  claude_skill_path="$GEO_ACTION_TEST_ROOT/claude-skills/geo-action"
elif [ "$system_name" = "Darwin" ]; then
  install_directory="$task_user_home/Library/Application Support/GEO Action"
  manifest_path="$task_user_home/Library/Application Support/Google/Chrome/NativeMessagingHosts/cn.wattter.geo_action.json"
  binary_path="$task_user_home/.local/bin/geo-action"
  codex_skill_path="$task_user_home/.codex/skills/geo-action"
  claude_skill_path="$task_user_home/.claude/skills/geo-action"
else
  data_root="${XDG_DATA_HOME:-$task_user_home/.local/share}"
  config_root="${XDG_CONFIG_HOME:-$task_user_home/.config}"
  install_directory="$data_root/geo-action"
  manifest_path="$config_root/google-chrome/NativeMessagingHosts/cn.wattter.geo_action.json"
  binary_path="$task_user_home/.local/bin/geo-action"
  codex_skill_path="$task_user_home/.codex/skills/geo-action"
  claude_skill_path="$task_user_home/.claude/skills/geo-action"
fi

rm -f "$manifest_path"
rm -f "$binary_path"
rm -rf "$codex_skill_path"
rm -rf "$claude_skill_path"

if [ -n "$install_directory" ] && [ "$install_directory" != "/" ]; then
  rm -rf "$install_directory"
fi

printf '%s\n' "GEO Action CLI、Native Host 注册和已安装 Skill 已移除。"
printf '%s\n' "已创建的平台草稿和 Chrome 扩展本地数据未删除。"
