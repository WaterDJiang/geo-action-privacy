$ErrorActionPreference = 'Stop'
$installDirectory = Join-Path $env:LOCALAPPDATA 'GeoAction'
$binaryDirectory = Join-Path $installDirectory 'bin'
$registryPath = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\cn.wattter.geo_action'

Remove-Item -Recurse -Force $registryPath -ErrorAction SilentlyContinue
foreach ($skillPath in @(
  (Join-Path $HOME '.codex\skills\geo-action'),
  (Join-Path $HOME '.claude\skills\geo-action')
)) {
  Remove-Item -Recurse -Force $skillPath -ErrorAction SilentlyContinue
}

$currentPath = [Environment]::GetEnvironmentVariable('Path', 'User')
$nextPath = (($currentPath -split ';') |
  Where-Object { $_ -and $_ -ne $binaryDirectory }) -join ';'
[Environment]::SetEnvironmentVariable('Path', $nextPath, 'User')

Remove-Item -Recurse -Force $installDirectory -ErrorAction SilentlyContinue
Write-Host 'GEO Action CLI、Native Host 注册和已安装 Skill 已移除。'
Write-Host '已创建的平台草稿和 Chrome 扩展本地数据未删除。'
